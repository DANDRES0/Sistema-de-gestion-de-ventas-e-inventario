import psycopg2 as ps
class ConexionBD:
    def __init__(self):
        self.con = None

    def establecer_conexion(self):
        try:
            self.con = ps.connect(
                database="GestionVentasDilan",
                user="postgres",
                password="Maria19",
                host="localhost",
                port="5432"
            )
            print("Conexión establecida correctamente.")
            return self.con
        except (Exception, ps.Error) as error:
            print("Error al conectarse a la base de datos:", error)

    def cerrar_conexion(self):
        if self.con:
            self.con.close()
            print("Conexión cerrada correctamente.")
    