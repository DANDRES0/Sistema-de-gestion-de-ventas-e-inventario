import psycopg2 as ps
from ConectorBDpost import *
            
# Función para crear la tabla de usuarios
def crear_tabla_usuarios():
    conexion = ConexionBD()  
    con = conexion.establecer_conexion()  
    
    try:
        cursor = con.cursor()
        query = '''
            CREATE TABLE IF NOT EXISTS usuarios (
                nombre VARCHAR(100) PRIMARY KEY,
                correo VARCHAR(100),
                contraseña VARCHAR(100)
            )
        '''
        cursor.execute(query)
        con.commit()
        print("Tabla de usuarios creada correctamente.")
    except (Exception, ps.Error) as error:
        print("Error al crear la tabla de usuarios:", error)
    finally:
        if con:
            cursor.close()
            con.close()

# Función para crear la tabla de clientes
def crear_tabla_clientes():
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    
    try:
        cursor = con.cursor()
        query = '''
            CREATE TABLE IF NOT EXISTS clientes (
                nombre VARCHAR(100) PRIMARY KEY,
                correo VARCHAR(100)
            )
        '''
        cursor.execute(query)
        con.commit()
        print("Tabla de clientes creada correctamente.")
    except (Exception, ps.Error) as error:
        print("Error al crear la tabla de clientes:", error)
    finally:
        if con:
            cursor.close()
            con.close()            

# Función para crear la tabla de facturas
def crear_tabla_facturas():
    conexion = ConexionBD()
    con = conexion.establecer_conexion()

    try:
        cursor = con.cursor()
        query = '''           
            CREATE TABLE IF NOT EXISTS facturas (
                id SERIAL PRIMARY KEY,
                vendedor_nombre VARCHAR(100),
                cliente_nombre VARCHAR(100),
                tipo_pago VARCHAR(100),
                fecha_venta DATE,
                precio_total FLOAT,
                FOREIGN KEY (vendedor_nombre) REFERENCES usuarios(nombre),
                FOREIGN KEY (cliente_nombre) REFERENCES clientes(nombre)
            )
        '''
        cursor.execute(query)
        con.commit()
        print("Tabla de facturas creada correctamente.")
    except (Exception, ps.Error) as error:
        print("Error al crear la tabla de facturas:", error)
    finally:
        if con:
            cursor.close()
            con.close()



# Funcion para crear la tabla ventas
def crear_tabla_ventas():
    conexion = ConexionBD()
    con = conexion.establecer_conexion()

    try:
        cursor = con.cursor()
        query = '''
            CREATE TABLE IF NOT EXISTS ventas (
            id SERIAL PRIMARY KEY,
            producto VARCHAR(100),
            cantidad INTEGER,
            unidades INTEGER,
            precio FLOAT,
            importe FLOAT
            )
        '''
        cursor.execute(query)
        con.commit()
        print("Tabla de ventas creada correctamente.")
    except (Exception, ps.Error) as error:
        print("Error al crear la tabla de ventas:", error)
    finally:
        if con:
            cursor.close()
            con.close()

# Función para crear la tabla de inventario
def crear_tabla_inventario():
    conexion = ConexionBD()  
    con = conexion.establecer_conexion()  
      
    try:
        cursor = con.cursor()
        query = '''
            CREATE TABLE IF NOT EXISTS inventario (
            id SERIAL PRIMARY KEY,
            codigo VARCHAR(100),
            producto VARCHAR(100),
            modelo VARCHAR(100),
            precio FLOAT,
            cantidad INT          
            )

        '''
        cursor.execute(query)
        con.commit()
        print("Tabla de inventario creada correctamente.")
    except (Exception, ps.Error) as error:
        print("Error al crear la tabla de inventario:", error)
    finally:
        if con:
            cursor.close()
            con.close()


# Función para registrar un nuevo usuario
def registrar_usuario(nombre, correo, contraseña):
    conexion = ConexionBD()  
    con = conexion.establecer_conexion()  
      
    try:
        cursor = con.cursor()
        query = "INSERT INTO usuarios (nombre, correo, contraseña) VALUES (%s, %s, %s)"
        valores = (nombre, correo, contraseña)
        cursor.execute(query, valores)
        con.commit()
        print("Usuario registrado correctamente. Nombre del usuario:", nombre)
    except (Exception, ps.Error) as error:
        print("Error al registrar el usuario:", error)
    finally:
        if con:
            cursor.close()
            con.close()

# Función para crear un nuevo cliente
def crear_nuevo_cliente(nombre, correo):
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    
    try:
        cursor = con.cursor()
        query = "INSERT INTO clientes (nombre, correo) VALUES (%s, %s) RETURNING nombre"
        valores = (nombre, correo)
        cursor.execute(query, valores)
        nombre = cursor.fetchone()[0]
        con.commit()
        print("Cliente registrado correctamente. nombre del cliente:", nombre)
    except (Exception, ps.Error) as error:
        print("Error al registrar el cliente:", error)
    finally:
        if con:
            cursor.close()
            con.close()

# Función para agregar un producto a la tabla de inventario
def agregar_producto_inventario(codigo, producto, modelo, precio, cantidad):
    conexion = ConexionBD()  
    con = conexion.establecer_conexion()  
      
    try:
        cursor = con.cursor()
        query = "INSERT INTO inventario (codigo, producto, modelo, precio, cantidad) VALUES (%s, %s, %s, %s, %s) RETURNING codigo"
        valores = (codigo, producto, modelo, precio, cantidad)
        cursor.execute(query, valores)
        codigo = cursor.fetchone()[0]
        con.commit()
        print("Producto agregado correctamente. Código de producto:", codigo)
    except (Exception, ps.Error) as error:
        print("Error al agregar el producto:", error)
    finally:
        if con:
            cursor.close()
            con.close()

# Función para obtener todo el inventario
def obtener_inventario():
    conexion = ConexionBD()  
    con = conexion.establecer_conexion()  
      
    try:
        cursor = con.cursor()
        query = "SELECT * FROM inventario"
        cursor.execute(query)
        inventario = cursor.fetchall()
        if inventario:
            print("Lista de inventario:")
            for producto in inventario:
                print("Código:", producto[0])
                print("Producto:", producto[1])
                print("Modelo:", producto[2])
                print("precio x unidad:", producto[3])
                print("Cantidad de productos:", producto[4])
                print("------------------------")
        else:
            print("No hay inventario en la base de datos.")
    except (Exception, ps.Error) as error:
        print("Error al obtener el inventario:", error)
    finally:
        if con:
            cursor.close()
            con.close()

# Función para generar una factura
def generar_factura(vendedor_nombre, cliente_nombre, tipo_pago, fecha_venta, precio_total):
    conexion = ConexionBD()
    con = conexion.establecer_conexion()

    try:
        cursor = con.cursor()
        query = "INSERT INTO facturas (vendedor_nombre, cliente_nombre, tipo_pago, fecha_venta, precio_total) VALUES (%s, %s, %s, %s, %s) RETURNING vendedor_nombre"
        valores = (vendedor_nombre, cliente_nombre, tipo_pago, fecha_venta, precio_total)
        cursor.execute(query, valores)
        vendedor_nombre = cursor.fetchone()[0]
        con.commit()
        print("Factura generada correctamente. Vendedor:", vendedor_nombre)
    except (Exception, ps.Error) as error:
        print("Error al generar la factura:", error)
    finally:
        if con:
            cursor.close()
            con.close()


# CREAMOS LA TABLA USUARIOS
crear_tabla_usuarios()

# CREAMOS LA TABLA CLIENTES
crear_tabla_clientes()

# CREAMOS LA TABLA INVENTARIO
crear_tabla_inventario()

# CREAMOS LA TABLA FACTURAS
crear_tabla_facturas()

#CREAMOS LA TABLA VENTAS
crear_tabla_ventas()

# AGREGAMOS EL USUARIO ADMIN A LA APLICACION 
registrar_usuario("admin","admin@pro.es","123")

# EJEMPLO DE CLIENTE
crear_nuevo_cliente("Daniel", "daniel@ejemplo.com")

# EJEMPLO PARA COMPROBAR QUE LOS PRODUCTOS SE AGREGAN CORRECTAMENTE
agregar_producto_inventario("P001", "smartwatch", "Modelo z", 199.99,20)

# EJEMPLO PARA GENERAR UNA FACTURA QUE HA COMPRADO DICHO CLIENTE
generar_factura("admin","Daniel","TARJETA","2023/06/12",199.99)

# EJEMPLO PARA COMPROBAR QUE LOS PRODUCTOS SE HAYAN AGREGADO CORRECTAMENTE A LA TABLA INVENTARIO DE LA BASE DE DATOS :)
obtener_inventario()
