
from PyQt5 import QtWidgets, uic,QtCore
from messagebox import msg_about, msg_error
from Gestion_de_ventas_pro import *
from gestion_productos_top import *
from funciones_productos import *
from funciones_ventas import *
from inicio_ui import *
from registro_ui import *
from datetime import date
import ConectorBDpost
# Creamos una instancia de ConexionBD
con = ConectorBDpost.ConexionBD()
# Establecer la conexión
con.establecer_conexion()
# Cerrar la conexión
con.cerrar_conexion()

# iniciar la aplicación
stockManager = QtWidgets.QApplication([])

# Cargar archivos .ui
inicio= uic.loadUi("inicio.ui")
registro = uic.loadUi("registro.ui")
opciones = uic.loadUi("opciones.ui")
ventas= uic.loadUi("Gestion_de_ventas_pro.ui")
productos= uic.loadUi("Gestion_productos_top.ui")

#funcion para iniciar sesion 
def gui_inicio():
    nombre = inicio.lineEdit.text()
    contra = inicio.lineEdit_2.text()

    if len(nombre) == 0 or len(contra) == 0:
        inicio.label_5.setText("Ingrese todos los datos para iniciar sesión")
    else:
        cursor = con.cursor()
        cursor.execute('SELECT nombre, contrasena FROM usuarios WHERE nombre = ? AND contrasena = ?', (nombre, contra))
        if cursor.fetchall():
            iniciar_sesion()
        else:
            msg_error("Error", "El usuario o la contraseña no son correctas")

#funcion para registrarse en el sistema
def gui_registrar(nombre, correo, contra):
    cursor = con.cursor()
    try:
        cursor.execute("INSERT INTO usuarios (nombre, correo, contrasena) VALUES (?, ?, ?)", (nombre, correo, contra))
        con.commit()
        con.close()
        return True
    except Exception as e:
        print("Error al registrar los datos:", e)
        return False


#funcion para registrar los usuarios
def datos():
    nombre = registro.line_nombre.text()
    correo = registro.line_correo.text()
    contra = registro.line_contra.text()
    contra_2 = registro.line_contra_2.text()
    
    if not nombre or not correo or not contra or not contra_2:
        msg_error("Error", "Por favor, completa todos los campos.")
        return
    
    if contra != contra_2:
        msg_error("Error", "Las contraseñas no son iguales, vuelve a intentarlo")
        return
    
    if gui_registrar(nombre, correo, contra):
        msg_about("Éxito!", "Se ha registrado exitosamente! \nTu nombre es tu usuario")
    else:
        msg_error("Error", "LOS DATOS NO SE HAN PODIDO REGISTRAR")

    registro.line_nombre.setText("")
    registro.line_correo.setText("")
    registro.line_contra.setText("")
    registro.line_contra_2.setText("")


#TODAS LAS FUNCIONES DE LA PARTE DE GESTION DE VENTAS 

def eliminar_filas_venta():
	cursor=con.cursor()
	cursor.execute('DELETE * FROM ventas')
	con.commit()
 
def base_datos(fila,columna):
	cursor=con.cursor()
	cursor.execute('SELECT * FROM inventario')
	rows=cursor.fetchall()
	return rows[fila][columna]

def base_ventas(fila,columna):
	cursor=con.cursor()
	cursor.execute('SELECT * FROM ventas')
	rows=cursor.fetchall()
	return rows[fila][columna]
	
def escribir_base_datos(producto,cantidad,unidades,precio_und,importe):
	cursor=con.cursor()
	cursor.execute("INSERT INTO ventas values (\'"+producto+"\',\'"+cantidad+"\',\'"+unidades+"\',\'"+precio_und+"\',\'"+importe+"')")
	con.commit()
	cursor.close()
	con.close()
	
def lista_ventas(vendedor,clientes_id,tipo_pago,fecha_venta,precio_total):
	cursor=con.cursor()
	cursor.execute("INSERT INTO facturas values (\'"+vendedor+"\',\'"+clientes_id+"\',\'"+tipo_pago+"\',\'"+fecha_venta+"\',\'"+precio_total+"')")
	con.commit()
	cursor.close()
	con.close()
	
def precio_total(catd_elem):
	precio_total_venta=0
	for valor in range(0,catd_elem):
		precio_total_venta=int(base_ventas(valor,4))+precio_total_venta
		#print(precio_total_venta)
	#print(precio_total_venta)
	return precio_total_venta
	
def elemtos_ventas():
	cursor=con.cursor()
	cursor.execute('SELECT * FROM ventas')
	rows=cursor.fetchall()
	catd_elem=len(rows)
	return catd_elem
	
		
class MainWindow(QtWidgets.QMainWindow,Ui_sistema_ventas):
	def __init__(self,*args,**kwargs):
		QtWidgets.QMainWindow.__init__(self,*args,**kwargs)
		_translate=QtCore.QCoreApplication.translate
		self.setupUi(self)
		eliminar_filas_venta()
		today=date.today()
		item=self.tabla_int.item(1,3)
		self.fecha.setText(str(today))
		item=self.tabla_int.item(0,0)
		item.setText(_translate("sistema_ventas",base_datos(0,0)))
		for fil in range(0,10):
			for colum in range(0,5):
				item=self.tabla_int.item(fil,colum)
				item.setText(_translate("sistema_ventas",str(base_datos(fil,colum))))
				if(colum==5):
					cantidad=int(base_datos(fil,colum-1))
					precio=int(base_datos(fil,colum-2))
					precio_total=cantidad*precio
					item.setText(_translate("sistema_ventas",str(precio_total)+'.00'))
					
		
		self.bot_agregar.clicked.connect(self.accion)
		self.generar_venta.clicked.connect(self.gen_vent)
		self.terminar.clicked.connect(self.terminar_venta)
		
	def accion(self):
		#aea=self.cod_bus.text()
		for valor in range(0,10):
			if(base_datos(valor,0)==self.cod_bus.text()):
				self.nom_pro.setText(base_datos(valor,1))
				self.Lab.setText(base_datos(valor,2))
				self.p_unit.setText(base_datos(valor,4))
				cant=self.spinBox.text()
				monto_und=int(base_datos(valor,4))*int(cant)
				if(int(cant)>0):
					self.monto_t.setText(str(monto_und)+".00")
				else:
					self.monto_t.setText(".00")
	
	def gen_vent(self):
		_translate=QtCore.QCoreApplication.translate
		producto=self.nom_pro.text()
		cantidad=self.spinBox.text()
		unidades="und"
		precio_und=self.p_unit.text()
		importe=int(cantidad)*int(precio_und)
		escribir_base_datos(producto,cantidad,unidades,precio_und,str(importe))
		cnd_elem=elemtos_ventas()
		item=self.boleta.item(cnd_elem-1,0)
		item.setText(_translate("sistema_ventas",producto))
		item=self.boleta.item(cnd_elem-1,1)
		item.setText(_translate("sistema_ventas",cantidad))
		item=self.boleta.item(cnd_elem-1,2)
		item.setText(_translate("sistema_ventas",unidades))
		item=self.boleta.item(cnd_elem-1,3)
		item.setText(_translate("sistema_ventas",precio_und))
		item=self.boleta.item(cnd_elem-1,4)
		item.setText(_translate("sistema_ventas",str(importe)+'.00'))
		self.total_general.setText(str(precio_total(cnd_elem))+'.00')
			
	def terminar_venta(self):
		vendedor=self.vendedor.text()
		cliente=self.cliente.text()
		tipo_pago=self.tipo_pago.currentText()
		fecha_venta=self.fecha.text()
		aea=elemtos_ventas()
		monto_t=precio_total(aea)
		lista_ventas(vendedor,cliente,tipo_pago,fecha_venta,str(monto_t)+'.00')
		eliminar_filas_venta()
  
'''-----------------------------------------------------------------------------------------------'''        
#TODAS LAS FUNCIONES DE LA GESTION DE PRODUCTOS

class MiApp(QtWidgets.QMainWindow):
	def __init__(self):
		super().__init__()
		self.ui = Ui_productos() 
		self.ui.setupUi(self)

		self.datosTotal = ConexionBD()
		self.ui.bt_refrescar.clicked.connect(self.m_productos)
		self.ui.bt_agregar.clicked.connect(self.insert_productos)
		self.ui.bt_buscar.clicked.connect(self.buscar_producto)
		self.ui.bt_borrar.clicked.connect(self.eliminar_producto)
		self.ui.bt_actualizar.clicked.connect(self.modificar_productos)
		
		self.ui.tabla_productos.setColumnWidth(0,98)
		self.ui.tabla_productos.setColumnWidth(1,100)
		self.ui.tabla_productos.setColumnWidth(2,98)
		self.ui.tabla_productos.setColumnWidth(3,98)
		self.ui.tabla_productos.setColumnWidth(4,98)

		self.ui.tabla_borrar.setColumnWidth(0,98)
		self.ui.tabla_borrar.setColumnWidth(1,100)
		self.ui.tabla_borrar.setColumnWidth(2,98)
		self.ui.tabla_borrar.setColumnWidth(3,98)
		self.ui.tabla_borrar.setColumnWidth(4,98)

		self.ui.tabla_buscar.setColumnWidth(0,98)
		self.ui.tabla_buscar.setColumnWidth(1,100)
		self.ui.tabla_buscar.setColumnWidth(2,98)
		self.ui.tabla_buscar.setColumnWidth(3,98)
		self.ui.tabla_buscar.setColumnWidth(4,98)

def m_productos(self):	
		datos = self.datosTotal.buscar_productos()
		i = len(datos)

		self.ui.tabla_productos.setRowCount(i)
		tablerow = 0
		for row in datos:
			self.ui.tabla_productos.setItem(tablerow,0,QtWidgets.QTableWidgetItem(row[1]))
			self.ui.tabla_productos.setItem(tablerow,1,QtWidgets.QTableWidgetItem(row[2]))
			self.ui.tabla_productos.setItem(tablerow,2,QtWidgets.QTableWidgetItem(row[3]))
			self.ui.tabla_productos.setItem(tablerow,3,QtWidgets.QTableWidgetItem(row[4]))
			self.ui.tabla_productos.setItem(tablerow,4,QtWidgets.QTableWidgetItem(row[5]))
			tablerow +=1
def insert_productos(self):
		codigo = self.ui.codigoA.text() 
		nombre = self.ui.nombreA.text()
		modelo = self.ui.modeloA.text()
		precio = self.ui.precioA.text()
		cantidad = self.ui.cantidadA.text()

		self.datosTotal.inserta_producto(codigo, nombre, modelo, precio, cantidad)
		self.ui.codigoA.clear()
		self.ui.nombreA.clear()
		self.ui.modeloA.clear()
		self.ui.precioA.clear()
		self.ui.cantidadA.clear()

def modificar_productos(self):
		id_producto = self.ui.id_producto.text() 
		id_producto = str("'" + id_producto + "'")
		nombreXX = self.datosTotal.busca_producto(id_producto)

		if nombreXX != None:
			self.ui.id_buscar.setText("ACTUALIZAR")
			codigoM = self.ui.codigo_actualizar.text() 
			nombreM = self.ui.nombre_actualizar.text()
			modeloM = self.ui.modelo_actualizar.text()
			precioM = self.ui.precio_actualizar.text()
			cantidadM = self.ui.cantidad_actualizar.text()
			act = self.datosTotal.actualiza_productos(codigoM,nombreM , modeloM, precioM, cantidadM)
			if act == 1:
				self.ui.id_buscar.setText("ACTUALIZADO")				
				self.ui.codigo_actualizar.clear()
				self.ui.nombre_actualizar.clear()
				self.ui.modelo_actualizar.clear()
				self.ui.precio_actualizar.clear()
				self.ui.cantidad_actualizar.clear()
				self.ui.id_producto.clear()
			elif act == 0:
				self.ui.id_buscar.setText("ERROR")
			else:
				self.ui.id_buscar.setText("INCORRECTO")		
		else:
			self.ui.id_buscar.setText("NO EXISTE")

def buscar_producto(self):
		nombre_producto = self.ui.codigoB.text()
		nombre_producto = str("'" + nombre_producto + "'")

		datosB = self.datosTotal.busca_producto(nombre_producto)
		i = len(datosB)

		self.ui.tabla_buscar.setRowCount(i)
		tablerow = 0
		for row in datosB:
			self.ui.tabla_buscar.setItem(tablerow,0,QtWidgets.QTableWidgetItem(row[1]))
			self.ui.tabla_buscar.setItem(tablerow,1,QtWidgets.QTableWidgetItem(row[2]))
			self.ui.tabla_buscar.setItem(tablerow,2,QtWidgets.QTableWidgetItem(row[3]))
			self.ui.tabla_buscar.setItem(tablerow,3,QtWidgets.QTableWidgetItem(row[4]))
			self.ui.tabla_buscar.setItem(tablerow,4,QtWidgets.QTableWidgetItem(row[5]))
			tablerow +=1

def eliminar_producto(self):
		eliminar = self.ui.codigo_borrar.text()
		eliminar = str("'"+ eliminar + "'")
		resp = (self.datosTotal.elimina_productos(eliminar))
		datos = self.datosTotal.buscar_productos()
		i = len(datos)
		self.ui.tabla_borrar.setRowCount(i)
		tablerow = 0
		for row in datos:
			self.ui.tabla_borrar.setItem(tablerow,0,QtWidgets.QTableWidgetItem(row[1]))
			self.ui.tabla_borrar.setItem(tablerow,1,QtWidgets.QTableWidgetItem(row[2]))
			self.ui.tabla_borrar.setItem(tablerow,2,QtWidgets.QTableWidgetItem(row[3]))
			self.ui.tabla_borrar.setItem(tablerow,3,QtWidgets.QTableWidgetItem(row[4]))
			self.ui.tabla_borrar.setItem(tablerow,4,QtWidgets.QTableWidgetItem(row[5]))
			tablerow +=1
		if resp == None:
			self.ui.borrar_ok.setText("NO EXISTE")
		elif resp == 0:
			self.ui.borrar_ok.setText("NO EXISTE")
		else:
			self.ui.borrar_ok.setText("SE ELIMINO")


        
        
        
#Funciones para abrir y cerrar las sistema_ventass        
def gui_inicio():
    inicio.show()
    
    
def gui_registrar():
    inicio.hide()
    registro.show()

def regresar_inicio():
    registro.hide()
    inicio.show()
    
def iniciar_sesion():
    
    inicio.hide()
    opciones.show()
    
def regresar_opciones():
    opciones.hide()
    inicio.show()
    
       #ventas 
def cargar_ventas():
    opciones.hide()
    ventas.show()
    
def regresar_ventas():
    ventas.hide()
    opciones.show() 
    #productos
def cargar_productos():
    opciones.hide()
    productos.show()

def regresar_productos():
    productos.hide()
    opciones.show()

def salir():
    stockManager.exit()

# Botones de inicio
inicio.pushButton.clicked.connect(iniciar_sesion)
inicio.pushButton_3.clicked.connect(gui_registrar)
inicio.pushButton_2.clicked.connect(salir)

# Botones de registrar
registro.btn_regresar.clicked.connect(regresar_inicio)

registro.btn_registrar.clicked.connect(datos)

# Botones de opciones
opciones.btn_regresar.clicked.connect(regresar_opciones)
opciones.bt_ventas.clicked.connect(cargar_ventas)
opciones.bt_productos.clicked.connect(cargar_productos)
opciones.bt_salir.clicked.connect(salir)

# Botones de productos
productos.btn_regresar.clicked.connect(regresar_productos)
productos.bt_refrescar.clicked.connect(m_productos)
productos.bt_agregar.clicked.connect(insert_productos)
productos.bt_buscar.clicked.connect(buscar_producto)
productos.bt_borrar.clicked.connect(eliminar_producto)
productos.bt_actualizar.clicked.connect(modificar_productos)


'''
#botones de ventas 
ventas.btn_regresar.clicked.connect(regresar_ventas)
ventas.generar_venta.clicked.connect(cargar_ventas)
ventas.agregar_prod.clicked.connect(cargar_productos)
ventas.bt_salir.clicked.connect(salir)
'''

# Ejecutar app rapidamente
inicio.show()
stockManager.exec()