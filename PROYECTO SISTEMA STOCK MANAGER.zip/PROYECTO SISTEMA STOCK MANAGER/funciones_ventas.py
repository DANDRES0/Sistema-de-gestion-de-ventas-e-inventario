from Gestion_de_ventas_pro import *
from datetime import date
from PyQt5 import QtCore, QtWidgets
import psycopg2 as ps
class ConexionBD:
    def __init__(self):
        self.con = None

    def establecer_conexion(self):
        try:
            self.con = ps.connect(
                database="GestionVentasDilan",
                user="postgres",
                password="Maria19",
                host="localhost",
                port="5432"
            )
            print("Conexión establecida correctamente.")
            return self.con
        except (Exception, ps.Error) as error:
            print("Error al conectarse a la base de datos:", error)

    def cerrar_conexion(self):
        if self.con:
            self.con.close()
            print("Conexión cerrada correctamente.")

def eliminar_filas_venta():
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    try:
        cursor = con.cursor()
        cursor.execute('DELETE FROM ventas')
        con.commit()
        print("Filas eliminadas correctamente.")
    except (Exception, ps.Error) as error:
        print("Error al eliminar las filas:", error)
    finally:
        if con:
            cursor.close()
            con.close()
def base_datos(fila, columna):
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    try:
        cursor = con.cursor()
        cursor.execute('SELECT * FROM inventario')
        rows = cursor.fetchall()
        if fila < len(rows):
            return rows[fila][columna]
        return None
    except (Exception, ps.Error) as error:
        print("Error al obtener los datos de la tabla inventario:", error)
    finally:
        if con:
            cursor.close()
            con.close()

def base_ventas(fila, columna):
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    try:
        cursor = con.cursor()
        cursor.execute('SELECT * FROM ventas')
        rows = cursor.fetchall()
        if fila < len(rows):
            return rows[fila][columna]
        return None
    except (Exception, ps.Error) as error:
        print("Error al obtener los datos de la tabla ventas:", error)
    finally:
        if con:
            cursor.close()
            con.close()

def escribir_base_datos(producto, cantidad, unidades, precio, importe):
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    try:
        cursor = con.cursor()
        cursor.execute("INSERT INTO ventas VALUES (producto, cantidad, unidades, precio, importe) (%s, %s, %s, %s, %s)",
                       (producto, cantidad, unidades, precio, importe))
        con.commit()
        print("Datos escritos correctamente en la tabla ventas.")
    except (Exception, ps.Error) as error:
        print("Error al escribir los datos en la tabla ventas:", error)
    finally:
        if con:
            cursor.close()
            con.close()

def lista_ventas(vendedor, cliente, tipo_pago, fecha_venta, precio_total):
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    try:
        cursor = con.cursor()
        cursor.execute("INSERT INTO facturas (vendedor_nombre, cliente_nombre, tipo_pago, fecha_venta, precio_total) VALUES (%s, %s, %s, %s, %s)",
                       (vendedor, cliente, tipo_pago, fecha_venta, precio_total))
        con.commit()
        print("Datos escritos correctamente en la tabla facturas.")
    except (Exception, ps.Error) as error:
        print("Error al escribir los datos en la tabla facturas:", error)
    finally:
        if con:
            cursor.close()
            con.close()


def precio_total(catd_elem):
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    try:
        cursor = con.cursor()
        cursor.execute('SELECT * FROM ventas')
        rows = cursor.fetchall()
        precio_total_venta = 0
        for valor in range(0, catd_elem):
            precio_total_venta = int(rows[valor][4]) + precio_total_venta
        return precio_total_venta
    except (Exception, ps.Error) as error:
        print("Error al obtener el precio total de las ventas:", error)
    finally:
        if con:
            cursor.close()
            con.close()

def elementos_ventas():
    conexion = ConexionBD()
    con = conexion.establecer_conexion()
    try:
        cursor = con.cursor()
        cursor.execute('SELECT * FROM ventas')
        rows = cursor.fetchall()
        catd_elem = len(rows)
        return catd_elem
    except (Exception, ps.Error) as error:
        print("Error al obtener los elementos de la tabla ventas:", error)
    finally:
        if con:
            cursor.close()
            con.close()

	
class MainWindow(QtWidgets.QMainWindow,Ui_sistema_ventas):
	def __init__(self,*args,**kwargs):
		QtWidgets.QMainWindow.__init__(self,*args,**kwargs)
		_translate=QtCore.QCoreApplication.translate
		self.setupUi(self)
		eliminar_filas_venta()
		today=date.today()
		item=self.tabla_int.item(1,3)
		self.fecha.setText(str(today))
		item=self.tabla_int.item(0,0)
		item.setText(_translate("sistema_ventas", str(base_datos(0, 0))))
		for fil in range(0,10):
			for colum in range(0,5):
				item=self.tabla_int.item(fil,colum)
				item.setText(_translate("sistema_ventas",str(base_datos(fil,colum))))
				if(colum==5):
					cantidad=int(base_datos(fil + 1, colum - 1))
					precio=int(base_datos(fil + 1, colum - 2))
					precio_total=cantidad*precio
					item.setText(_translate("sistema_ventas",str(precio_total)+'.00'))
					
		
		self.bot_agregar.clicked.connect(self.accion)
		self.generar_venta.clicked.connect(self.gen_vent)
		self.terminar.clicked.connect(self.terminar_venta)
		
	def accion(self):
		#aea=self.cod_bus.text()
		for valor in range(0,10):
			if(base_datos(valor,0)==self.cod_bus.text()):
				self.nom_pro.setText(base_datos(valor,2))
				self.Lab.setText(base_datos(valor,3))
				self.p_unit.setText(base_datos(valor,4))
				cant=self.spinBox.text()
				monto_und=int(base_datos(valor,4))*int(cant)
				if(int(cant)>0):
					self.monto_t.setText(str(monto_und)+".00")
				else:
					self.monto_t.setText(".00")
	
	def gen_vent(self):
		_translate=QtCore.QCoreApplication.translate
		producto=self.nom_pro.text()
		cantidad=self.spinBox.text()
		unidades="UNIDADES"
		precio=self.p_unit.text()
		importe=int(cantidad)*float(precio)
		escribir_base_datos(producto,cantidad,unidades,precio,str(importe))
		cnd_elem=elementos_ventas()
		item=self.boleta.item(cnd_elem-1,0)
		item.setText(_translate("sistema_ventas",producto))
		item=self.boleta.item(cnd_elem-1,1)
		item.setText(_translate("sistema_ventas",cantidad))
		item=self.boleta.item(cnd_elem-1,2)
		item.setText(_translate("sistema_ventas",unidades))
		item=self.boleta.item(cnd_elem-1,3)
		item.setText(_translate("sistema_ventas",precio))
		item=self.boleta.item(cnd_elem-1,4)
		item.setText(_translate("sistema_ventas",str(importe)+'.00'))
		self.total_general.setText(str(precio_total(cnd_elem))+'.00')
			
	def terminar_venta(self):
		vendedor=self.vendedor.text()
		cliente=self.cliente.text()
		tipo_pago=self.tipo_pago.currentText()
		fecha_venta=self.fecha.text()
		aea=elementos_ventas()
		monto_t=precio_total(aea)
		lista_ventas(vendedor,cliente,tipo_pago,fecha_venta,str(monto_t)+'.00')
		eliminar_filas_venta()
	
if __name__=="__main__":

	app=QtWidgets.QApplication([])
	window=MainWindow()
	window.show()
	app.exec_()