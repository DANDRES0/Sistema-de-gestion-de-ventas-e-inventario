
import psycopg2 as ps
class ConexionBD:
    def __init__(self):
        self.con = None

    def establecer_conexion(self):
        try:
            self.con = ps.connect(
                database="GestionVentasDilan",
                user="postgres",
                password="Maria19",
                host="localhost",
                port="5432"
            )
            print("Conexión establecida correctamente.")
            return self.con
        except (Exception, ps.Error) as error:
            print("Error al conectarse a la base de datos:", error)

    def cerrar_conexion(self):
        if self.con:
            self.con.close()
            print("Conexión cerrada correctamente.")

    def inserta_producto(self, codigo, producto, modelo, precio, cantidad):
        cursor = self.conexion.cursor()
        query = "INSERT INTO inventario (CODIGO, producto, MODELO, PRECIO, CANTIDAD) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(query, (codigo, producto, modelo, precio, cantidad))
        self.conexion.commit()
        cursor.close()

    def buscar_inventario(self):
        cursor = self.conexion.cursor()
        query = "SELECT * FROM inventario"
        cursor.execute(query)
        registro = cursor.fetchall()
        return registro

    def busca_producto(self, producto_producto):
        cursor = self.conexion.cursor()
        query = "SELECT * FROM inventario WHERE producto = %s"
        cursor.execute(query, (producto_producto,))
        productox = cursor.fetchall()
        cursor.close()
        return productox

    def elimina_inventario(self, producto):
        cursor = self.conexion.cursor()
        query = "DELETE FROM inventario WHERE producto = %s"
        cursor.execute(query, (producto,))
        nom = cursor.rowcount
        self.conexion.commit()
        cursor.close()
        return nom

    def actualiza_inventario(self, codigo, producto, modelo, precio, cantidad):
        cursor = self.conexion.cursor()
        query = "UPDATE inventario SET CODIGO = %s, MODELO = %s, PRECIO = %s, CANTIDAD = %s WHERE producto = %s"
        cursor.execute(query, (codigo, modelo, precio, cantidad, producto))
        act = cursor.rowcount
        self.conexion.commit()
        cursor.close()
        return act
